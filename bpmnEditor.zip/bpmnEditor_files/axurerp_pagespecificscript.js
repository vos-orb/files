﻿for(var i = 0; i < 73; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u13'] = 'center';
$axure.eventManager.change('u50', function(e) {

if ((GetSelectedOption('u50')) == ('Start Event')) {

	SetPanelState('u51', 'pd0u51','none','',500,'none','',500);

}
else
if ((GetSelectedOption('u50')) == ('Intermediate Event')) {

	SetPanelState('u51', 'pd1u51','none','',500,'none','',500);

}
else
if ((GetSelectedOption('u50')) == ('End Event')) {

	SetPanelState('u51', 'pd2u51','none','',500,'none','',500);

}
});

$axure.eventManager.focus('u50', function(e) {

if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

}
});

$axure.eventManager.blur('u50', function(e) {

if (true) {

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

}
});
document.getElementById('u54_img').tabIndex = 0;

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if ((GetGlobalVariableValue('status')) != ('selected')) {

	SetPanelState('u49', 'pd1u49','none','',500,'none','',500);

	SetPanelState('u23', 'pd1u23','none','',500,'none','',500);

SetGlobalVariableValue('status', 'selected');

}
else
if ((GetGlobalVariableValue('status')) == ('selected')) {

	SetPanelState('u49', 'pd0u49','none','',500,'none','',500);

	SetPanelVisibility('u23','hidden','none',500);

SetGlobalVariableValue('status', 'unselected');

}
});
gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u59'] = 'center';